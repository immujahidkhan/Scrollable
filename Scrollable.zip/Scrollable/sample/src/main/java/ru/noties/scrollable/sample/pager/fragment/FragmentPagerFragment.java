package ru.noties.scrollable.sample.pager.fragment;

import ru.noties.scrollable.CanScrollVerticallyDelegate;
import ru.noties.scrollable.OnFlingOverListener;
import ru.noties.scrollable.sample.BaseFragment;

abstract class FragmentPagerFragment extends BaseFragment implements CanScrollVerticallyDelegate, OnFlingOverListener {

}
